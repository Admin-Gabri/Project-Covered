//{
    //"id": 0,
    //"username": "Gabri",
    //"firstName": "Gomez",
    //"lastName": "Paz",
    //"email": "gabri@gmail.com",
    //"password": "123456789",
    //"phone": "909032091",
    //"userStatus": 0
  //}

//[
    //{
      //"id": 0,
      //"username": "Gabri",
      //"firstName": "Gomez",
      //"lastName": "Paz",
      //"email": "gabri@hotmail.com",
      //"password": "123456789",
      //"phone": "909032091",
      //"userStatus": 0
    //}
  //]

  //{
    //"id": 0,
    //"username": "Gabri",
    //"firstName": "Gomez",
    //"lastName": "Paz",
    //"email": "gabri@hotmail.com",
    //"password": "123456789",
    //"phone": "909032091",
    //"userStatus": 0
  //}
